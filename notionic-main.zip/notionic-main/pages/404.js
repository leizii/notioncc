import NotFound from '@/components/NotFound'

export default function Custom404() {
  return <NotFound statusCode='404' />
}
